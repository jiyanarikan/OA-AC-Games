# Bid–Offer Drill

A quick-fire quiz for market-making interview fundamentals: reading quotes, hitting and lifting,
getting flat, P&L, spreads, inventory skew, adverse selection and pit-game fair value.

It learns which question types you miss and asks those more often until you're getting them right.

## Run it

No install and no build step. Open `index.html` in any browser; it works fully offline.

To host it, push this folder to GitHub and turn on **Settings → Pages** (deploy from the branch root).
The drill will be at `https://<user>.github.io/<repo>/`.

## How the adaptive picker works

`js/adaptive.js` keeps a small model of your answers per question type (19 types):

1. **Recent miss rate.** Each answer updates a decayed count of attempts and misses (older answers
   keep 85% of their weight each time the type comes up again), so recent answers matter most and a
   type you've fixed cools off. The rate is smoothed toward 30% so one answer can't swing it to 0% or 100%.
2. **Weight.** `base mix × (0.1 + 4 × miss rate) × staleness`. The base mix leans toward the harder
   dynamics. Staleness adds up to +30% to types you already know but haven't seen for a while, so
   they still come back for review.
3. **Guard rails.** No type can take more than 30% of the draw, and the same type is never asked twice
   in a row.

In simulation (3,000 questions, a learner who gets two types right only ~35–40% of the time and everything
else 90%), those two weak types come up about 2.5× as often as in the fixed mix, and every other type
still appears.

The **Focus areas** panel shows each type's misses, recent miss rate, and its chance of being asked next.
The switch next to it turns adaptation off and returns to the fixed mix. On first load the model learns
from any question logs already saved in the browser.

## Data

Everything is stored in the browser's `localStorage` (session history, question logs, the model and
the switch setting). Nothing leaves your device. **Clear history** wipes all of it, including the model.

## Files

```
index.html          page shell
css/styles.css      styles (light and dark)
js/questions.js     question bank: 19 randomized templates + typed-answer parser
js/adaptive.js      the adaptive model
js/app.js           UI: questions, scoring, history, question log, focus areas
tests/              Node tests for the model and every question template
```

## Tests

Requires Node 18+ and no dependencies:

```
npm test
```

The tests generate 400 questions of every type and check each is well-formed (exactly one correct
option, no duplicate options, typed answers pass their own check). They also check the model: misses
raise a type's share, correct answers lower it, and the 30% cap holds. A seeded simulation checks
that weak types are asked at least twice as often.
