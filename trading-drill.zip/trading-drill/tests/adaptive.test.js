const test = require("node:test");
const assert = require("node:assert/strict");
const AdaptiveModel = require("../js/adaptive.js");
const { TYPES } = require("../js/questions.js");

const types = TYPES.map((t) => ({ id: t.id, base: t.base }));
const sum = (o) => Object.values(o).reduce((s, x) => s + x, 0);

// Deterministic PRNG so the simulation tests are repeatable.
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

test("probabilities sum to 1 and respect the excluded type", () => {
  const m = new AdaptiveModel(types);
  const p = m.probabilities("makerTakerMix");
  assert.ok(Math.abs(sum(p) - 1) < 1e-9);
  assert.equal(p.makerTakerMix, undefined);
});

test("with no history, adaptive mode matches the base mix", () => {
  const m = new AdaptiveModel(types);
  const a = m.probabilities(null, true), b = m.probabilities(null, false);
  for (const id of Object.keys(b)) assert.ok(Math.abs(a[id] - b[id]) < 1e-9, id);
});

test("missing a type raises how often it is asked", () => {
  const m = new AdaptiveModel(types);
  const before = m.probabilities(null).crossedMarket;
  m.record("crossedMarket", false);
  m.record("crossedMarket", false);
  const after = m.probabilities(null).crossedMarket;
  assert.ok(after > before * 1.5, before + " -> " + after);
  assert.ok(m.isFocus("crossedMarket"));
});

test("getting a type right lowers it, and a fixed weakness cools off", () => {
  const m = new AdaptiveModel(types);
  const base = m.probabilities(null).spread;
  m.record("spread", false); m.record("spread", false);
  const weak = m.probabilities(null).spread;
  for (let i = 0; i < 8; i++) m.record("spread", true);
  const fixed = m.probabilities(null).spread;
  assert.ok(weak > base && fixed < weak && fixed < base, [base, weak, fixed].join(" "));
  assert.ok(!m.isFocus("spread"));
});

test("recent answers outweigh old ones", () => {
  const oldMisses = new AdaptiveModel(types), recentMisses = new AdaptiveModel(types);
  [0, 0, 0, 1, 1, 1].forEach((ok) => oldMisses.record("mmSkew", !!ok));
  [1, 1, 1, 0, 0, 0].forEach((ok) => recentMisses.record("mmSkew", !!ok));
  assert.ok(recentMisses.missRate("mmSkew") > oldMisses.missRate("mmSkew"));
});

test("no single type can exceed the share cap", () => {
  const m = new AdaptiveModel(types);
  for (let i = 0; i < 30; i++) m.record("makerTakerMix", false);
  const p = m.probabilities(null);
  assert.ok(p.makerTakerMix <= m.opts.maxShare + 1e-9, String(p.makerTakerMix));
  assert.ok(Math.abs(sum(p) - 1) < 1e-9);
});

test("capShares redistributes excess proportionally", () => {
  const p = AdaptiveModel.capShares([0.7, 0.2, 0.1], 0.5);
  assert.ok(Math.abs(p[0] - 0.5) < 1e-9);
  assert.ok(Math.abs(p[1] - 1 / 3) < 1e-9 && Math.abs(p[2] - 1 / 6) < 1e-9);
});

test("save and load round-trips, and bad data is ignored", () => {
  const m = new AdaptiveModel(types);
  m.record("hedger", false); m.record("spread", true);
  const copy = new AdaptiveModel(types);
  assert.ok(copy.load(JSON.parse(JSON.stringify(m.toJSON()))));
  assert.deepEqual(copy.probabilities(null), m.probabilities(null));
  assert.equal(new AdaptiveModel(types).load(null), false);
  const tolerant = new AdaptiveModel(types);
  assert.ok(tolerant.load({ clock: 3, stats: { hedger: { n: "x", miss: -1 }, removedType: { n: 5 } } }));
  assert.ok(Math.abs(sum(tolerant.probabilities(null)) - 1) < 1e-9);
});

test("replay learns from old logs that only stored the tag", () => {
  const m = new AdaptiveModel(types);
  const tagToId = {}; TYPES.forEach((t) => { tagToId[t.label] = t.id; });
  m.replay([{ tag: "Crossed market", ok: false }, { type: "spread", ok: true }, { tag: "Unknown", ok: false }], tagToId);
  assert.equal(m.stats.crossedMarket.totalMiss, 1);
  assert.equal(m.stats.spread.total, 1);
  assert.equal(m.clock, 2);
});

test("simulated learner: weak types get asked far more than in the base mix", () => {
  const rand = mulberry32(42);
  const weakTypes = { insideMarket: 0.35, markToExit: 0.4 };   // chance of answering correctly
  const count = (adaptive) => {
    const m = new AdaptiveModel(types);
    const seen = {}; let last = null;
    for (let i = 0; i < 3000; i++) {
      const id = m.pick(rand, last, adaptive);
      last = id; seen[id] = (seen[id] || 0) + 1;
      const pCorrect = weakTypes[id] != null ? weakTypes[id] : 0.9;
      if (adaptive) m.record(id, rand() < pCorrect);
    }
    return seen;
  };
  const plain = count(false), adaptive = count(true);
  for (const id of Object.keys(weakTypes)) {
    assert.ok(adaptive[id] > plain[id] * 2, id + ": plain " + plain[id] + ", adaptive " + adaptive[id]);
  }
  // Mastered types still come up.
  for (const t of types) assert.ok((adaptive[t.id] || 0) > 0, t.id + " never asked");
});
