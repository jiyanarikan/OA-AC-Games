const test = require("node:test");
const assert = require("node:assert/strict");
const { TYPES, generate, evalAnswer } = require("../js/questions.js");

const RUNS = 400;
const BAD_TEXT = /NaN|undefined|null|Infinity/;

test("every question type generates well-formed questions", () => {
  for (const t of TYPES) {
    for (let i = 0; i < RUNS; i++) {
      const qn = generate(t.id);
      const where = t.id + " #" + i;
      assert.equal(qn.type, t.id, where);
      assert.equal(qn.tag, t.label, where + ": tag must be fixed per type");
      assert.ok(qn.prompt && !BAD_TEXT.test(qn.prompt), where + ": prompt " + qn.prompt);
      assert.ok(qn.explain && !BAD_TEXT.test(qn.explain), where + ": explain " + qn.explain);
      if (qn.text) {
        const v = evalAnswer(qn.answer);
        assert.ok(!isNaN(v), where + ": answer parses");
        assert.ok(qn.check(v), where + ": the stated answer " + qn.answer + " passes its own check");
      } else {
        assert.ok(qn.options.length >= 2, where);
        assert.equal(qn.options.filter((o) => o.ok).length, 1, where + ": exactly one correct option");
        const texts = qn.options.map((o) => o.t);
        assert.equal(new Set(texts).size, texts.length, where + ": duplicate options " + texts.join(" | "));
        texts.forEach((x) => assert.ok(!BAD_TEXT.test(x), where + ": option " + x));
      }
    }
  }
});

test("typed answers accept plain numbers and simple arithmetic", () => {
  assert.equal(evalAnswer("1"), 1);
  assert.equal(evalAnswer("88.5-87.5"), 1);
  assert.equal(evalAnswer("88.5 − 87.5"), 1);
  assert.equal(evalAnswer("(177 − 173) × 6"), 24);
  assert.equal(evalAnswer("-8"), -8);
  assert.equal(evalAnswer("$12"), 12);
  assert.equal(evalAnswer("0,25"), 0.25);
  assert.equal(evalAnswer("10 / 4"), 2.5);
  for (const bad of ["", "abc", "1+", "(1", "2*/3", "1..2"]) assert.ok(isNaN(evalAnswer(bad)), bad);
});
