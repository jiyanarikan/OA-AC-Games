/* UI: question flow, scoring, session history, question log and the focus-areas panel. */
(function () {
  "use strict";

  const { TYPES, generate, evalAnswer } = window.DrillQuestions;
  const AdaptiveModel = window.AdaptiveModel;

  const labelOf = {};
  const tagToId = {};
  TYPES.forEach((t) => { labelOf[t.id] = t.label; tagToId[t.label] = t.id; });

  // ---------- persistence ----------
  const KEY = "tradingDrill.sessions.v1";
  const MODEL_KEY = "tradingDrill.model.v1";
  const PREFS_KEY = "tradingDrill.prefs.v1";
  const LOG_SESSIONS = 30;   // keep full question logs for the most recent sessions
  const LOG_MAX = 500;       // cap per session

  function readJSON(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key)); return v == null ? fallback : v; }
    catch (e) { return fallback; }
  }
  function writeJSON(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage unavailable */ }
  }

  function loadSessions() { const v = readJSON(KEY, []); return Array.isArray(v) ? v : []; }
  function saveSessions(list) {
    const trimmed = list.slice(-100).map((s, i, arr) => {
      if (i < arr.length - LOG_SESSIONS && s.log) { const c = Object.assign({}, s); delete c.log; return c; }
      return s;
    });
    writeJSON(KEY, trimmed);
  }

  let sessions = loadSessions();
  let current = null;
  function newSession() { current = { id: Date.now(), date: new Date().toISOString(), correct: 0, total: 0, log: [] }; streak = 0; }
  function persistCurrent() {
    if (!current || current.total === 0) return;
    const i = sessions.findIndex((s) => s.id === current.id);
    if (i >= 0) sessions[i] = Object.assign({}, current); else sessions.push(Object.assign({}, current));
    saveSessions(sessions);
  }

  // ---------- adaptive model ----------
  const model = new AdaptiveModel(TYPES.map((t) => ({ id: t.id, base: t.base })));
  if (!model.load(readJSON(MODEL_KEY, null))) {
    // First run with the model: learn from any question logs already saved.
    sessions.slice().sort((a, b) => a.id - b.id).forEach((s) => model.replay(s.log || [], tagToId));
    writeJSON(MODEL_KEY, model.toJSON());
  }
  const prefs = Object.assign({ adaptive: true }, readJSON(PREFS_KEY, {}));

  // ---------- rendering ----------
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const pct = (x) => Math.round(100 * x) + "%";
  let streak = 0;
  let lastType = null;
  let state = null;      // { q, answered }
  let viewId = null;     // null = current session's log; otherwise a past session id
  let reviewIdx = null;  // index of the logged question being reviewed

  function fmtDate(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric" }) + ", " +
      d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  }

  function renderHistory() {
    const rows = sessions.slice().reverse();
    if (!rows.length) {
      $("history").innerHTML = '<p class="empty">No sessions yet. Answer a question and it will be saved here.</p>';
      $("clear-slot").hidden = true;
      return;
    }
    $("clear-slot").hidden = false;
    $("history").innerHTML =
      '<div class="table-scroll"><table><thead><tr><th>Date</th><th class="r">Score</th><th class="r">Accuracy</th></tr></thead><tbody>' +
      rows.map((s) => {
        const cur = current && s.id === current.id;
        const viewing = viewId !== null && s.id === viewId;
        return '<tr data-id="' + s.id + '" class="' + (cur ? "current" : "") + (viewing ? " viewing" : "") + '" title="Show this session\'s questions"><td>' + fmtDate(s.date) + (cur ? " · now" : "") +
          '</td><td class="r">' + s.correct + " / " + s.total +
          '</td><td class="r">' + Math.round((100 * s.correct) / s.total) + "%</td></tr>";
      }).join("") + "</tbody></table></div>";
  }

  function renderScore() {
    $("s-score").textContent = current.correct + " / " + current.total;
    $("s-acc").textContent = current.total ? pct(current.correct / current.total) : "—";
    $("s-streak").textContent = streak;
  }

  // ---------- focus areas ----------
  function renderFocus() {
    const rows = model.summary(lastType, prefs.adaptive);
    const weak = rows.filter((r) => r.focus);
    const answered = rows.some((r) => r.total > 0);
    let text;
    if (!answered) text = "Answer a few questions and your weak spots show up here.";
    else if (!weak.length) text = "No weak spots right now: you aren't regularly missing any question type.";
    else {
      text = "Weakest: " + weak.slice(0, 3).map((r) => "<b>" + esc(labelOf[r.id]) + "</b>").join(", ") +
        (prefs.adaptive ? ". These come up more often until you're getting them right." : ". Turn on the switch to practise them more.");
    }
    $("focus-summary").innerHTML = text;

    $("focus-table").innerHTML =
      '<div class="table-scroll"><table><thead><tr><th>Type</th><th class="r">Missed</th><th class="r">Recent</th><th class="r">Next</th></tr></thead><tbody>' +
      rows.map((r) => '<tr class="' + (r.focus ? "is-focus" : "") + '"><td class="type">' + esc(labelOf[r.id]) + "</td>" +
        '<td class="r">' + (r.total ? r.missed + " / " + r.total : "—") + "</td>" +
        '<td class="r">' + (r.total ? pct(r.missRate) : "—") + "</td>" +
        '<td class="r"><span class="bar"><i style="width:' + Math.min(100, Math.round(r.askRate * 300)) + '%"></i></span>' + pct(r.askRate) + "</td></tr>"
      ).join("") + "</tbody></table></div>" +
      '<p class="focus-key">Missed: all-time misses / attempts. Recent: miss rate weighted toward your latest answers. ' +
      "Next: chance this type is the next question" + (prefs.adaptive ? "." : " (fixed mix while the switch is off).") + "</p>";
  }

  // ---------- question log ----------
  function viewedSession() {
    if (viewId === null) return current;
    return sessions.find((s) => s.id === viewId) || current;
  }
  function viewedLog() { const s = viewedSession(); return (s && s.log) || []; }

  function renderLog() {
    const s = viewedSession();
    const log = viewedLog();
    const isCurrent = s === current;
    if (reviewIdx !== null && !log[reviewIdx]) reviewIdx = null;

    let meta = (isCurrent ? "This session" : fmtDate(s.date)) + " · " + log.length + " answered";
    if (!isCurrent) meta += ' <button class="linkbtn" id="log-back" type="button">Back to this session</button>';
    $("log-meta").innerHTML = meta;

    if (!log.length) {
      $("log-chips").innerHTML = '<p class="empty">' + (isCurrent
        ? "Answered questions appear here. Tap a number to review it."
        : "No question log for this session (it was played before logging was added).") + "</p>";
    } else {
      $("log-chips").innerHTML = log.map((e, i) =>
        '<button class="chip ' + (e.ok ? "ok" : "bad") + (i === reviewIdx ? " sel" : "") + '" type="button" data-i="' + i +
        '" aria-label="Question ' + (i + 1) + ", " + (e.ok ? "correct" : "incorrect") + '">' + (i + 1) + "</button>").join("");
    }
    renderReview();
  }

  function renderReview() {
    const box = $("review");
    const log = viewedLog();
    const e = reviewIdx === null ? null : log[reviewIdx];
    if (!e) { box.hidden = true; box.innerHTML = ""; return; }

    let h = '<div class="review-head"><span class="label">Question ' + (reviewIdx + 1) + " / " + log.length + " · " + e.tag +
      '</span><button class="linkbtn" data-act="close" type="button">Close</button></div>' +
      '<p class="prompt">' + e.prompt + "</p>";
    if (e.text) {
      h += '<p class="typed">Your answer: <b class="num">' + esc(e.typed) + "</b>" +
        (e.ok ? "" : " · Correct answer: <b class=\"num\">" + esc(e.answer) + "</b>") + "</p>";
    } else {
      h += '<div class="options">' + e.options.map((o, k) => {
        const cls = o.ok ? "is-correct" : (k === e.chosen ? "is-wrong" : "dim");
        return '<div class="opt ' + cls + '"><kbd>' + (k + 1) + "</kbd><span>" + o.t +
          (k === e.chosen ? '<em class="pick">your pick</em>' : "") + "</span></div>";
      }).join("") + "</div>";
    }
    h += '<div class="feedback ' + (e.ok ? "good" : "bad") + '"><span class="verdict">' + (e.ok ? "Correct" : "Incorrect") +
      '</span><p class="explain">' + e.explain + "</p></div>" +
      '<div class="next-row"><button class="btn ghost" data-act="prev" type="button"' + (reviewIdx === 0 ? " disabled" : "") + ">← Previous</button>" +
      '<span class="keys">← → to move, Esc to close</span>' +
      '<button class="btn ghost" data-act="next" type="button"' + (reviewIdx === log.length - 1 ? " disabled" : "") + ">Next</button></div>";
    box.innerHTML = h;
    box.hidden = false;
  }

  function openReview(i) {
    reviewIdx = i;
    renderLog();
    if (reviewIdx !== null) $("review").scrollIntoView({ block: "nearest" });
  }

  // ---------- question flow ----------
  function nextQuestion() {
    const id = model.pick(Math.random, lastType, prefs.adaptive);
    lastType = id;
    state = { q: generate(id), answered: false };
    renderQuestion();
    renderFocus();
  }

  function renderQuestion() {
    const qn = state.q;
    const focus = prefs.adaptive && model.isFocus(qn.type);
    let body = '<span class="label">' + qn.tag + (focus ? ' <span class="focus-tag">· Focus area</span>' : "") +
      '</span><p class="prompt">' + qn.prompt + "</p>";
    if (qn.text) {
      body += '<form class="textrow" id="text-form" autocomplete="off">' +
        '<input id="text-answer" inputmode="decimal" placeholder="' + qn.placeholder + '" aria-label="Your answer">' +
        '<button class="btn" type="submit">Check</button></form>' +
        '<p class="hint" id="text-hint">Type a number (or a sum like 88.5 − 87.5) and press Enter.</p>';
    } else {
      body += '<div class="options" role="group" aria-label="Answers">' +
        qn.options.map((o, k) => '<button class="opt" type="button" data-k="' + k + '"><kbd>' + (k + 1) + "</kbd><span>" + o.t + "</span></button>").join("") +
        "</div>";
    }
    body += '<div id="feedback-slot"></div>';
    $("card").innerHTML = body;

    if (qn.text) {
      const input = $("text-answer");
      $("text-form").addEventListener("submit", (e) => {
        e.preventDefault();
        if (state.answered) return;
        const v = evalAnswer(input.value);
        if (isNaN(v)) {
          const hint = $("text-hint");
          hint.textContent = input.value.trim() === ""
            ? "Type your answer first."
            : "Couldn't read “" + input.value.trim() + "”. Enter a number like 1.5 (sums like 88.5 − 87.5 work too).";
          hint.classList.add("err");
          input.focus();
          return;
        }
        input.disabled = true;
        e.target.querySelector("button").disabled = true;
        answer(qn.check(v), { typed: input.value.trim() });
      });
      input.focus({ preventScroll: true });
    } else {
      $("card").querySelectorAll(".opt").forEach((b) => b.addEventListener("click", () => choose(Number(b.dataset.k))));
    }
  }

  function choose(k) {
    if (state.answered) return;
    const qn = state.q;
    const ok = !!qn.options[k].ok;
    $("card").querySelectorAll(".opt").forEach((b, idx) => {
      b.disabled = true;
      if (qn.options[idx].ok) b.classList.add("is-correct");
      else if (idx === k) b.classList.add("is-wrong");
      else b.classList.add("dim");
    });
    answer(ok, { chosen: k });
  }

  function answer(ok, detail) {
    const qn = state.q;
    detail = detail || {};
    state.answered = true;
    current.total++;
    if (ok) { current.correct++; streak++; } else { streak = 0; }
    if (!current.log) current.log = [];
    if (current.log.length < LOG_MAX) {
      current.log.push({
        type: qn.type,
        tag: qn.tag,
        prompt: qn.prompt,
        text: !!qn.text,
        options: qn.text ? null : qn.options.map((o) => ({ t: o.t, ok: !!o.ok })),
        chosen: typeof detail.chosen === "number" ? detail.chosen : null,
        typed: detail.typed != null ? detail.typed : null,
        answer: qn.answer != null ? String(qn.answer) : null,
        ok: !!ok,
        explain: qn.explain
      });
    }
    model.record(qn.type, ok);
    writeJSON(MODEL_KEY, model.toJSON());
    persistCurrent();
    renderScore();
    renderHistory();
    renderFocus();
    if (viewId === null) renderLog();

    let note = "";
    if (prefs.adaptive && !ok) note = '<p class="adapt-note">You\'ll see more “' + esc(labelOf[qn.type]) + "” questions until you're getting them right.</p>";
    const verdict = ok ? "Correct" : "Incorrect" + (qn.text ? ": it's " + qn.answer : "");
    $("feedback-slot").innerHTML =
      '<div class="feedback ' + (ok ? "good" : "bad") + '" role="status"><span class="verdict">' + verdict +
      '</span><p class="explain">' + qn.explain + "</p>" + note + "</div>" +
      '<div class="next-row" style="margin-top:16px"><span class="keys">Enter for next</span>' +
      '<button class="btn" id="next-btn" type="button">Next question →</button></div>';
    const nb = $("next-btn");
    nb.addEventListener("click", nextQuestion);
    nb.focus({ preventScroll: true });
  }

  // ---------- events ----------
  // Keyboard: 1–4 to answer, Enter for next. While reviewing: ← → to move, Esc to close.
  document.addEventListener("keydown", (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const ae = document.activeElement;
    const typing = ae && ae.tagName === "INPUT" && ae.type !== "checkbox";
    if (reviewIdx !== null && !typing) {
      const n = viewedLog().length;
      if (e.key === "Escape") { e.preventDefault(); reviewIdx = null; renderLog(); return; }
      if (e.key === "ArrowLeft" && reviewIdx > 0) { e.preventDefault(); openReview(reviewIdx - 1); return; }
      if (e.key === "ArrowRight" && reviewIdx < n - 1) { e.preventDefault(); openReview(reviewIdx + 1); return; }
    }
    if (!state) return;
    if (ae && ae.closest && ae.closest(".log, .history, .focus")) return;   // let panel controls handle their own keys
    if (state.answered && e.key === "Enter" && ae && ae.id !== "next-btn") {
      e.preventDefault(); nextQuestion(); return;
    }
    if (!state.answered && !state.q.text) {
      const n = Number(e.key);
      if (n >= 1 && n <= state.q.options.length) choose(n - 1);
    }
  });

  $("adaptive-toggle").checked = prefs.adaptive;
  $("adaptive-toggle").addEventListener("change", (e) => {
    prefs.adaptive = e.target.checked;
    writeJSON(PREFS_KEY, prefs);
    renderFocus();
  });

  $("log-chips").addEventListener("click", (e) => {
    const b = e.target.closest(".chip");
    if (!b) return;
    const i = Number(b.dataset.i);
    openReview(reviewIdx === i ? null : i);
  });

  $("log-meta").addEventListener("click", (e) => {
    if (e.target.id !== "log-back") return;
    viewId = null; reviewIdx = null;
    renderHistory(); renderLog();
  });

  $("review").addEventListener("click", (e) => {
    const a = e.target.closest("[data-act]");
    if (!a || a.disabled) return;
    const act = a.dataset.act;
    if (act === "close") { reviewIdx = null; renderLog(); }
    else if (act === "prev" && reviewIdx > 0) openReview(reviewIdx - 1);
    else if (act === "next" && reviewIdx < viewedLog().length - 1) openReview(reviewIdx + 1);
  });

  $("history").addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-id]");
    if (!tr) return;
    const id = Number(tr.dataset.id);
    viewId = current && id === current.id ? null : id;
    reviewIdx = null;
    renderHistory(); renderLog();
  });

  $("new-session").addEventListener("click", () => {
    persistCurrent();
    newSession();
    viewId = null; reviewIdx = null;
    renderScore(); renderHistory(); renderLog(); nextQuestion();
  });

  // In-page confirm for clearing history (no native dialogs). Clearing also resets the model.
  $("clear-slot").addEventListener("click", (e) => {
    const t = e.target;
    if (t.id === "clear-btn") {
      $("clear-slot").innerHTML = '<span class="confirm">Delete all saved sessions and focus areas? ' +
        '<button class="linkbtn" id="clear-yes" type="button">Delete</button>' +
        '<button class="linkbtn" id="clear-no" type="button">Keep</button></span>';
    } else if (t.id === "clear-yes" || t.id === "clear-no") {
      if (t.id === "clear-yes") {
        sessions = []; saveSessions(sessions);
        model.reset(); writeJSON(MODEL_KEY, model.toJSON());
        current.total = 0; current.correct = 0; current.log = []; streak = 0;
        viewId = null; reviewIdx = null;
        renderScore(); renderLog(); renderFocus();
      }
      $("clear-slot").innerHTML = '<button class="linkbtn" id="clear-btn" type="button">Clear history</button>';
      renderHistory();
    }
  });

  newSession();
  renderScore();
  renderHistory();
  renderLog();
  nextQuestion();
})();
