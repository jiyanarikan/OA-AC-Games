/*
 * Question bank. Each template is a function returning a fresh random question:
 *   { tag, prompt, options:[{t, ok}] }            multiple choice
 *   { tag, prompt, text:true, check(v), answer }  typed numeric answer
 * plus `explain`, and optionally `fixedOrder` (don't shuffle options).
 *
 * The function name is the question type's id; the adaptive model keys on it.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.DrillQuestions = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ---------- helpers ----------
  const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  const pick = (arr) => arr[rnd(0, arr.length - 1)];
  const shuffle = (arr) => {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = rnd(0, i); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  };
  const clean = (x) => String(Number(x.toFixed(4)));
  const q = (text) => '<span class="quote">' + text + '</span>';

  // Reads a typed answer: a plain number or simple arithmetic like "88.5-87.5".
  // Hand-rolled parser (no eval) for + − × ÷ and parentheses.
  function evalAnswer(raw) {
    const s = String(raw).replace(/[\s$]/g, "").replace(/[−–—]/g, "-").replace(/[×x]/gi, "*").replace(/÷/g, "/").replace(/,/g, ".");
    if (!s || !/^[0-9.+\-*/()]+$/.test(s)) return NaN;
    let i = 0;
    const expr = () => {
      let v = term();
      while (s[i] === "+" || s[i] === "-") { const op = s[i++]; const r = term(); v = op === "+" ? v + r : v - r; }
      return v;
    };
    const term = () => {
      let v = factor();
      while (s[i] === "*" || s[i] === "/") { const op = s[i++]; const r = factor(); v = op === "*" ? v * r : v / r; }
      return v;
    };
    const factor = () => {
      if (s[i] === "-") { i++; return -factor(); }
      if (s[i] === "+") { i++; return factor(); }
      if (s[i] === "(") { i++; const v = expr(); if (s[i++] !== ")") throw 0; return v; }
      const m = /^(\d+\.?\d*|\.\d+)/.exec(s.slice(i));
      if (!m) throw 0;
      i += m[0].length;
      return parseFloat(m[0]);
    };
    try { const v = expr(); return i === s.length && isFinite(v) ? v : NaN; } catch (e) { return NaN; }
  }

  // Price conventions: whole numbers, halves, quarters, nickels.
  function pickStyle() {
    return pick([
      { tick: 1, dp: 0, lo: 8, hi: 180 },
      { tick: 1, dp: 0, lo: 8, hi: 180 },
      { tick: 0.5, dp: 1, lo: 40, hi: 400 },
      { tick: 0.25, dp: 2, lo: 200, hi: 1200 },
      { tick: 0.05, dp: 2, lo: 100, hi: 2000 }
    ]);
  }

  // A random two-sided quote, built in integer ticks to avoid float drift.
  function makeQuote() {
    const style = pickStyle();
    const bidT = rnd(style.lo, style.hi);
    const sprT = rnd(1, 6);
    const bid = bidT * style.tick, ask = (bidT + sprT) * style.tick;
    return {
      bid, ask, style, bidT, sprT,
      px: (ticks) => (ticks * style.tick).toFixed(style.dp),
      spread: sprT * style.tick,
      b: bid.toFixed(style.dp),
      a: ask.toFixed(style.dp),
      s: clean(sprT * style.tick),
      mid: clean((bid + ask) / 2),
      text: bid.toFixed(style.dp) + " at " + ask.toFixed(style.dp)
    };
  }

  // ---------- question templates ----------
  const templates = [
    function readQuote() {
      const Q = makeQuote();
      return {
        tag: "Reading a quote",
        prompt: "The market is " + q(Q.text) + ". Which price do you sell at, and which do you buy at?",
        options: [
          { t: "Sell at " + Q.b + ", buy at " + Q.a, ok: true },
          { t: "Sell at " + Q.a + ", buy at " + Q.b },
          { t: "Both at the mid, " + Q.mid },
          { t: "Sell at " + Q.a + ", buy at " + Q.a }
        ],
        explain: Q.b + " is the bid (what someone will pay you), so you sell there; " + Q.a + " is the offer, so you buy there."
      };
    },

    function aggressorVerbs() {
      const v = pick([
        { s: "You <b>lift an offer</b>.", buy: true, why: "Lifting an offer means taking someone's offer, so you bought." },
        { s: "You <b>hit a bid</b>.", buy: false, why: "Hitting a bid means selling into someone's bid, so you sold." },
        { s: "Someone <b>hits your bid</b>.", buy: true, why: "They sold into your bid, so you're the buyer." },
        { s: "Someone <b>lifts your offer</b>.", buy: false, why: "They bought your offer, so you're the seller." }
      ]);
      return {
        tag: "Hit or lift",
        prompt: v.s + " Did you buy or sell?",
        options: [{ t: "Bought", ok: v.buy }, { t: "Sold", ok: !v.buy }],
        fixedOrder: true,
        explain: v.why
      };
    },

    function flattenPosition() {
      const Q = makeQuote();
      const n = rnd(1, 12);
      const long = Math.random() < 0.5;
      const wrongN = pick([n + rnd(1, 3), n * 2]);
      const sell = (k) => "Sell " + k + " — hit the bid at " + Q.b;
      const buy = (k) => "Buy " + k + " — lift the offer at " + Q.a;
      return {
        tag: "Getting flat",
        prompt: "The market is " + q(Q.text) + ". You're <b>" + (long ? "long " : "short ") + n + "</b>. What single trade makes you flat?",
        options: long
          ? [{ t: sell(n), ok: true }, { t: "Sell " + n + " — lift the offer at " + Q.a }, { t: buy(n) }, { t: sell(wrongN) }]
          : [{ t: buy(n), ok: true }, { t: "Buy " + n + " — hit the bid at " + Q.b }, { t: sell(n) }, { t: buy(wrongN) }],
        explain: long
          ? "Long " + n + " means you must sell " + n + "; selling immediately means hitting the bid at " + Q.b + "."
          : "Short " + n + " means you must buy " + n + "; buying immediately means lifting the offer at " + Q.a + "."
      };
    },

    function tradeSequence() {
      const Q = makeQuote();
      let trades, net;
      do {
        trades = Array.from({ length: rnd(2, 4) }, () => ({ buy: Math.random() < 0.5, n: rnd(1, 10) }));
        net = trades.reduce((s, t) => s + (t.buy ? t.n : -t.n), 0);
      } while (net === 0);
      const gross = trades.reduce((s, t) => s + t.n, 0);
      const k = Math.abs(net);
      const wrongK = gross !== k ? gross : k + 2;
      const words = trades.map((t, i) => (i ? "then " : "") + (t.buy ? "buy " : "sell ") + t.n);
      const posName = (x) => (x > 0 ? "Long " : "Short ") + Math.abs(x);
      const fix = (x, sizeOverride) => {
        const s = sizeOverride || Math.abs(x);
        return x < 0 ? "buy " + s + ", lifting the offer at " + Q.a : "sell " + s + ", hitting the bid at " + Q.b;
      };
      const wrongVerb = net < 0 ? "buy " + k + ", hitting the bid at " + Q.b : "sell " + k + ", lifting the offer at " + Q.a;
      const math = trades.map((t, i) => (t.buy ? (i ? "+ " : "+") : (i ? "− " : "−")) + t.n).join(" ");
      return {
        tag: "Trade sequence",
        prompt: "The market is " + q(Q.text) + ". Starting flat, you <span class=\"trades\">" + words.join(", ") + "</span>. What's your position, and what trade flattens it?",
        options: [
          { t: posName(net) + " — " + fix(net), ok: true },
          { t: posName(-net) + " — " + fix(-net) },
          { t: posName(net) + " — " + wrongVerb },
          { t: posName(net > 0 ? wrongK : -wrongK) + " — " + fix(net, wrongK) }
        ],
        explain: math + " = " + (net > 0 ? "+" : "−") + k + ", so you're " + posName(net).toLowerCase() + "; to flatten, " + fix(net) + "."
      };
    },

    function spread() {
      const Q = makeQuote();
      return {
        tag: "Spread",
        prompt: "The market is " + q(Q.text) + ". What's the spread?",
        text: true,
        placeholder: "e.g. " + clean(Q.spread + 1),
        check: (v) => Math.abs(v - Q.spread) < 1e-6,
        answer: Q.s,
        explain: "Offer minus bid: " + Q.a + " − " + Q.b + " = " + Q.s + "."
      };
    },

    function hedger() {
      const h = pick([
        { who: "An airline", act: "buys next quarter's jet fuel from a market maker", risk: "fuel costs" },
        { who: "A farmer", act: "sells next season's corn to a market maker", risk: "the crop price" },
        { who: "A power company", act: "buys next winter's natural gas from a market maker", risk: "fuel costs" }
      ]);
      return {
        tag: "Why hedgers pay",
        prompt: h.who + " " + h.act + ", crossing the spread instead of waiting for a better price. Why pay the spread?",
        options: [
          { t: "For immediacy: they want the price locked in now, with certainty", ok: true },
          { t: "They expect the price to move in their favour" },
          { t: "Crossing the spread gets them a better price than the mid" },
          { t: "Market makers only trade with hedgers who pay the spread" }
        ],
        explain: "A hedger isn't trying to beat the market. The spread is the fee for removing the risk on " + h.risk + " right now, instead of carrying it while they wait."
      };
    },

    // ----- Market maker's seat: you set the bid and offer -----

    function mmTwoWay() {
      const st = pickStyle();
      const f = rnd(st.lo + 10, st.hi), e = rnd(1, 4);
      const p = (t) => (t * st.tick).toFixed(st.dp);
      const edge = clean(e * st.tick);
      return {
        tag: "Market maker · Showing a price",
        prompt: "You're the market maker. Your fair value is " + q(p(f)) + " and you want to earn " + edge + " on each side. What two-way price do you show?",
        options: [
          { t: p(f - e) + " at " + p(f + e), ok: true },
          { t: p(f + e) + " at " + p(f - e) },
          { t: p(f) + " at " + p(f + 2 * e) },
          { t: p(f - 2 * e) + " at " + p(f) }
        ],
        explain: "Bid below fair, offer above: " + p(f - e) + " at " + p(f + e) + ". You buy " + edge + " under value and sell " + edge + " over it."
      };
    },

    function mmRoundTrip() {
      const Q = makeQuote();
      const n = rnd(1, 20);
      const legs = shuffle(["<b>hits your bid</b> for " + n, "<b>lifts your offer</b> for " + n]);
      const pnl = Q.spread * n;
      return {
        tag: "Market maker · Round trip",
        prompt: "You're making a market at " + q(Q.text) + ". One client " + legs[0] + ", then another " + legs[1] + ". What's your total profit?",
        text: true,
        placeholder: "e.g. " + clean(Q.spread),
        check: (v) => Math.abs(v - pnl) < 1e-6,
        answer: clean(pnl),
        explain: "You bought " + n + " at " + Q.b + " and sold " + n + " at " + Q.a + ", so you're flat and earned the spread: " + Q.s + " × " + n + " = " + clean(pnl) + "."
      };
    },

    function mmGotFilled() {
      const Q = makeQuote();
      const n = rnd(1, 15);
      const lifted = Math.random() < 0.5;
      const half = clean(Q.spread / 2), edge = clean((Q.spread / 2) * n);
      const opt = (pos, gain) => pos + " " + n + ", " + (gain ? "earned " + edge + " vs the mid" : "lost " + edge + " vs the mid");
      return {
        tag: "Market maker · Getting filled",
        prompt: "You're quoting " + q(Q.text) + ". A client " + (lifted ? "<b>lifts your offer</b>" : "<b>hits your bid</b>") + " for " + n + ". What's your position, and how did you do against the mid (" + Q.mid + ")?",
        options: [
          { t: opt(lifted ? "Short" : "Long", true), ok: true },
          { t: opt(lifted ? "Long" : "Short", true) },
          { t: opt(lifted ? "Short" : "Long", false) },
          { t: opt(lifted ? "Long" : "Short", false) }
        ],
        explain: lifted
          ? "The client bought from you, so you're short " + n + ". You sold at " + Q.a + ", " + half + " above the mid: " + half + " × " + n + " = " + edge + " of edge."
          : "The client sold to you, so you're long " + n + ". You bought at " + Q.b + ", " + half + " below the mid: " + half + " × " + n + " = " + edge + " of edge."
      };
    },

    function mmSkew() {
      const Q = makeQuote();
      const n = rnd(20, 200);
      const long = Math.random() < 0.5;
      const b = Q.bidT, a = Q.bidT + Q.sprT, p = Q.px;
      const down = p(b - 1) + " at " + p(a - 1), up = p(b + 1) + " at " + p(a + 1);
      return {
        tag: "Market maker · Managing inventory",
        prompt: "You're the market maker quoting " + q(Q.text) + ". After a busy morning you're <b>" + (long ? "long " : "short ") + n + "</b>, more than you want to hold. How do you adjust your quote?",
        options: [
          { t: (long ? down : up) + " (shift " + (long ? "down" : "up") + ")", ok: true },
          { t: (long ? up : down) + " (shift " + (long ? "up" : "down") + ")" },
          { t: p(b - 1) + " at " + p(a + 1) + " (widen both sides)" },
          { t: Q.text + " (leave it and wait)" }
        ],
        explain: long
          ? "Long means you want to sell. A lower offer attracts buyers, and a lower bid makes clients less likely to sell you more."
          : "Short means you want to buy. A higher bid attracts sellers, and a higher offer makes clients less likely to buy more from you."
      };
    },

    function mmWidth() {
      const Q = makeQuote();
      const s = pick([
        { t: "A big earnings announcement is due in five minutes.", a: "Widen", why: "Fair value could jump on the news, so you need more cushion against trading at a stale price." },
        { t: "A client asks for a price in ten times your usual size.", a: "Widen", why: "Bigger size means more risk to hedge or unwind, so you charge more for it." },
        { t: "You're unsure of fair value; the product barely trades.", a: "Widen", why: "The less sure you are of value, the more edge you need to cover being wrong." },
        { t: "The market has gone quiet and volatility has dropped.", a: "Tighten", why: "Less risk of the price moving against you means you can quote tighter and win more flow." },
        { t: "Several competitors are now quoting tighter than you, and you're getting no trades.", a: "Tighten", why: "If your price is never the best, you trade nothing. Tighten to compete for flow." }
      ]);
      return {
        tag: "Market maker · Spread width",
        prompt: "You're the market maker quoting " + q(Q.text) + ". " + s.t + " What do you do with your spread?",
        options: [{ t: "Widen", ok: s.a === "Widen" }, { t: "Tighten", ok: s.a === "Tighten" }, { t: "Leave it unchanged" }],
        fixedOrder: true,
        explain: s.a + ". " + s.why
      };
    },

    // ----- Harder dynamics -----

    function insideMarket() {
      for (let tries = 0; tries < 200; tries++) {
        const st = pickStyle();
        const p = (t) => (t * st.tick).toFixed(st.dp);
        const base = rnd(st.lo + 10, st.hi);
        const qs = [0, 1, 2].map(() => { const b = base + rnd(-3, 1); return { b: b, a: b + rnd(2, 5) }; });
        const bb = Math.max.apply(null, qs.map((x) => x.b)), bo = Math.min.apply(null, qs.map((x) => x.a));
        if (bb >= bo) continue;
        const wb = Math.min.apply(null, qs.map((x) => x.b)), wa = Math.max.apply(null, qs.map((x) => x.a));
        const qBB = qs.find((x) => x.b === bb), qBO = qs.find((x) => x.a === bo);
        const cand = [
          { t: p(bb) + " at " + p(bo), ok: true },
          { t: p(wb) + " at " + p(wa) },
          { t: p(bb) + " at " + p(qBB.a) },
          { t: p(qBO.b) + " at " + p(bo) },
          { t: p(wb) + " at " + p(bo) },
          { t: p(bb) + " at " + p(wa) }
        ];
        const seen = new Set(), opts = [];
        cand.forEach((c) => { if (!seen.has(c.t)) { seen.add(c.t); opts.push(c); } });
        if (opts.length < 4) continue;
        const names = ["Trader A", "Trader B", "Trader C"];
        return {
          tag: "Best bid and offer",
          prompt: qs.map((x, i) => names[i] + " quotes " + q(p(x.b) + " at " + p(x.a))).join(". ") + ". What's the best market you can trade on right now?",
          options: opts.slice(0, 4),
          explain: "The best bid is the highest anyone will pay (" + p(bb) + "), and the best offer is the lowest anyone will sell at (" + p(bo) + "). They can come from different traders. As a taker you'd sell at " + p(bb) + " and buy at " + p(bo) + "."
        };
      }
      return templates[0]();
    },

    function crossedMarket() {
      const st = pickStyle();
      const p = (t) => (t * st.tick).toFixed(st.dp);
      const base = rnd(st.lo + 10, st.hi);
      const sA = rnd(1, 3), g = rnd(1, 3), sB = rnd(1, 3);
      const cheap = { b: base, a: base + sA }, rich = { b: base + sA + g, a: base + sA + g + sB };
      const swap = Math.random() < 0.5;
      const nc = swap ? "Trader B" : "Trader A", nr = swap ? "Trader A" : "Trader B";
      const lineC = nc + " quotes " + q(p(cheap.b) + " at " + p(cheap.a));
      const lineR = nr + " quotes " + q(p(rich.b) + " at " + p(rich.a));
      const edge = clean(g * st.tick);
      return {
        tag: "Crossed market",
        prompt: (swap ? lineR + ". " + lineC : lineC + ". " + lineR) + ". What do you do?",
        options: [
          { t: "Lift " + nc + "'s offer at " + p(cheap.a) + " and hit " + nr + "'s bid at " + p(rich.b), ok: true },
          { t: "Hit " + nc + "'s bid at " + p(cheap.b) + " and lift " + nr + "'s offer at " + p(rich.a) },
          { t: "Lift both offers and wait for the prices to converge" },
          { t: "Nothing: traders always disagree a little" }
        ],
        explain: nr + "'s bid (" + p(rich.b) + ") is above " + nc + "'s offer (" + p(cheap.a) + "), so the market is crossed. Buy from " + nc + " and sell to " + nr + " at the same time: you end flat and lock in " + edge + " per unit."
      };
    },

    function makerTakerMix() {
      const Q = makeQuote();
      let n1, n2;
      do { n1 = rnd(1, 12); n2 = rnd(1, 12); } while (n1 === n2);
      const clientLifts = Math.random() < 0.5;   // client lifts your offer -> you sell
      const youLift = Math.random() < 0.5;       // you lift another trader's offer -> you buy
      const s1 = clientLifts ? -1 : 1, s2 = youLift ? 1 : -1;
      const net = s1 * n1 + s2 * n2;
      const name = (x) => (x > 0 ? "Long " : "Short ") + Math.abs(x);
      const combos = [[1, 1], [1, -1], [-1, 1], [-1, -1]].map((c) => c[0] * n1 + c[1] * n2);
      return {
        tag: "Maker or taker?",
        prompt: "You're quoting " + q(Q.text) + ". A client <b>" + (clientLifts ? "lifts your offer" : "hits your bid") + "</b> for " + n1 +
          ". Then you <b>" + (youLift ? "lift another trader's offer" : "hit another trader's bid") + "</b> for " + n2 + ". What's your position?",
        options: combos.map((x) => ({ t: name(x), ok: x === net })),
        explain: "On your quote you're the maker: the client " + (clientLifts ? "bought from you, so −" : "sold to you, so +") + n1 +
          ". On their quote you're the taker: you " + (youLift ? "bought, so +" : "sold, so −") + n2 + ". Net " + (net > 0 ? "+" : "−") + Math.abs(net) + ": " + name(net).toLowerCase() + "."
      };
    },

    function realizedPnl() {
      const base = rnd(20, 150);
      const legs = Array.from({ length: rnd(2, 3) }, () => ({ n: rnd(1, 6), p: base + rnd(-4, 4) }));
      const total = legs.reduce((s, l) => s + l.n, 0);
      const exit = base + rnd(-5, 6);
      const long = Math.random() < 0.5;
      const pnl = legs.reduce((s, l) => s + l.n * (long ? exit - l.p : l.p - exit), 0);
      const words = legs.map((l, i) => (i ? "then " : "") + (long ? "buy " : "sell ") + l.n + " at " + l.p).join(", ");
      const math = legs.map((l) => l.n + " × (" + (long ? exit + " − " + l.p : l.p + " − " + exit) + ")").join(" + ");
      return {
        tag: "P&L · Several fills",
        prompt: "Starting flat, you <span class=\"trades\">" + words + "</span>. Then you " + (long ? "sell" : "buy back") + " all " + total + " at " + exit + ". What's your total P&amp;L? (Use a minus sign for a loss.)",
        text: true,
        placeholder: "e.g. 12 or -8",
        check: (v) => Math.abs(v - pnl) < 1e-6,
        answer: String(pnl),
        explain: (long ? "Each lot earns the exit price minus what you paid: " : "Each lot earns what you sold at minus the buy-back price: ") + math + " = " + pnl + "."
      };
    },

    function markToExit() {
      const Q = makeQuote();
      const n = rnd(2, 12);
      const long = Math.random() < 0.5;
      const entryT = Q.bidT + rnd(-4, Q.sprT + 4);
      const askT = Q.bidT + Q.sprT;
      const pnlT = long ? Q.bidT - entryT : entryT - askT;
      const pnl = pnlT * n * Q.style.tick;
      const exitPx = long ? Q.b : Q.a;
      return {
        tag: "P&L · Exit price",
        prompt: "You're <b>" + (long ? "long " : "short ") + n + "</b>, " + (long ? "bought" : "sold") + " at " + Q.px(entryT) + ". The market is now " + q(Q.text) + ". If you flatten right now, what's your P&amp;L? (Minus sign for a loss.)",
        text: true,
        placeholder: "e.g. 6 or -4",
        check: (v) => Math.abs(v - pnl) < 1e-6,
        answer: clean(pnl),
        explain: "To flatten a " + (long ? "long you sell, and selling now means hitting the bid" : "short you buy, and buying now means lifting the offer") + " at " + exitPx + ", not the mid. " +
          (long ? "(" + exitPx + " − " + Q.px(entryT) + ")" : "(" + Q.px(entryT) + " − " + exitPx + ")") + " × " + n + " = " + clean(pnl) + "."
      };
    },

    function adverseSelection() {
      const Q = makeQuote();
      const k = rnd(8, 25);
      const lifted = Math.random() < 0.5;
      return {
        tag: "Adverse selection",
        prompt: "You're quoting " + q(Q.text) + ". The same trader keeps " + (lifted ? "<b>lifting your offer</b>" : "<b>hitting your bid</b>") +
          ", even after you moved your price twice. You're now " + (lifted ? "short " : "long ") + k + ". What's the best read?",
        options: [
          { t: "They probably know fair value is " + (lifted ? "higher" : "lower") + ". Move your whole quote " + (lifted ? "up" : "down") + " and widen until the flow stops", ok: true },
          { t: "Great flow. Keep your quote and collect the spread every time" },
          { t: "Move your quote " + (lifted ? "down" : "up") + " so you trade with them even more" },
          { t: "Only move your " + (lifted ? "bid up" : "offer down") + " and leave the other side where it is" }
        ],
        explain: "One-sided flow from the same counterparty is information. You earn a small edge per trade but lose far more if they're right about value. Reprice in their direction and widen: this is adverse selection, the main risk a market maker manages."
      };
    },

    function endGameFlat() {
      const Q = makeQuote();
      const n = rnd(2, 9);
      const long = Math.random() < 0.5;
      return {
        tag: "Pit game · Final seconds",
        prompt: "Pit game, 15 seconds left, and you must finish <b>flat</b>. You're <b>" + (long ? "long " : "short ") + n + "</b> and the pit is " + q(Q.text) + ". What do you do?",
        options: long
          ? [
              { t: "Hit the bid at " + Q.b + " for " + n + " now, even though it costs a little", ok: true },
              { t: "Offer at " + Q.a + " and hope someone lifts you before the bell" },
              { t: "Do nothing: " + n + " lots is close enough to flat" },
              { t: "Lift the offer at " + Q.a + " for " + n }
            ]
          : [
              { t: "Lift the offer at " + Q.a + " for " + n + " now, even though it costs a little", ok: true },
              { t: "Bid at " + Q.b + " and hope someone hits you before the bell" },
              { t: "Do nothing: " + n + " lots is close enough to flat" },
              { t: "Hit the bid at " + Q.b + " for " + n }
            ],
        explain: (long ? "Long " + n + " means you must sell " + n + ". " : "Short " + n + " means you must buy " + n + ". ") +
          "Finishing flat is the rule, so certainty beats price. Crossing the spread costs a little; missing flat costs the game. It's the same immediacy a hedger pays for."
      };
    },

    function cardFairValue() {
      const N = rnd(4, 10);
      const variant = rnd(0, 2);
      const deck = "one 52-card deck (A=1, J=11, Q=12, K=13)";
      const cn = (v) => ({ 1: "A (1)", 11: "J (11)", 12: "Q (12)", 13: "K (13)" })[v] || String(v);
      if (variant === 0) {
        const fv = 7 * N;
        return {
          tag: "Pit game · Fair value",
          prompt: "A contract settles at the sum of " + N + " cards dealt face-down from " + deck + ". You've seen none of them. What's fair value?",
          text: true,
          placeholder: "e.g. 35",
          check: (v) => Math.abs(v - fv) < 1e-6,
          answer: String(fv),
          explain: "Each card averages (1 + 13) ÷ 2 = 7, so " + N + " cards average 7 × " + N + " = " + fv + "."
        };
      }
      const seen = variant === 1 ? [rnd(1, 13)] : [rnd(1, 13), rnd(1, 13)];
      const m = seen.length, S = seen[0] + (seen[1] || 0);
      const per = (364 - S) / (52 - m);
      const fv = S + (N - m) * per;
      return {
        tag: "Pit game · Fair value",
        prompt: "A contract settles at the sum of " + N + " cards dealt from " + deck + ". You can see " +
          (m === 1 ? "one of them: " + cn(seen[0]) : "two of them: " + cn(seen[0]) + " and " + cn(seen[1])) +
          ". What's fair value? (One decimal place is fine.)",
        text: true,
        placeholder: "e.g. 42.5",
        check: (v) => Math.abs(v - fv) < 0.15,
        answer: fv.toFixed(1),
        explain: "The whole deck sums to 364. Each unseen card averages (364 − " + S + ") ÷ " + (52 - m) + " ≈ " + per.toFixed(2) + ". So " + S + " + " + (N - m) + " × " + per.toFixed(2) +
          " ≈ " + fv.toFixed(1) + ". Quick sanity check: seen cards plus 7 per unseen card gives " + (S + 7 * (N - m)) + "."
      };
    }
  ];

  // Base mix before adaptation: fewer basics, more tricky dynamics.
  const WEIGHTS = {
    readQuote: 1.2, aggressorVerbs: 1, flattenPosition: 1, tradeSequence: 1, spread: 0.4, hedger: 0.2,
    mmTwoWay: 0.8, mmRoundTrip: 0.8, mmGotFilled: 1, mmSkew: 1.2, mmWidth: 1,
    insideMarket: 1.4, crossedMarket: 1.4, makerTakerMix: 2, realizedPnl: 1.5, markToExit: 1.5,
    adverseSelection: 1.4, endGameFlat: 1.2, cardFairValue: 1.6
  };

  // One entry per question type. Every template's tag is fixed, so one sample gives its label.
  const TYPES = templates.map((f) => ({
    id: f.name,
    base: WEIGHTS[f.name] || 1,
    label: f().tag,
    generate: f
  }));
  const byId = {};
  TYPES.forEach((t) => { byId[t.id] = t; });

  /** Build a question of the given type, with options shuffled unless order matters. */
  function generate(id) {
    const qn = byId[id].generate();
    qn.type = id;
    if (!qn.text && !qn.fixedOrder) qn.options = shuffle(qn.options);
    return qn;
  }

  return { TYPES, WEIGHTS, generate, evalAnswer };
});
