/*
 * Adaptive question picker.
 *
 * Tracks how often each question type is missed and asks the weak types more.
 *
 * For each type we keep an exponentially decayed count of attempts and misses,
 * so recent answers matter more than old ones and a type you've since fixed
 * cools off again. The estimated miss rate is smoothed with a prior so a
 * single answer doesn't swing it to 0% or 100%:
 *
 *   missRate = (decayedMisses + PRIOR_MISSES) / (decayedAttempts + PRIOR_ATTEMPTS)
 *
 * Each type's selection weight is then
 *
 *   weight = baseWeight × (FLOOR + GAIN × missRate) × staleness
 *
 * - baseWeight is the hand-tuned mix (fewer basics, more tricky dynamics).
 * - FLOOR keeps mastered types in rotation so they don't vanish entirely.
 * - staleness gently brings back types you already know but haven't seen for a
 *   while (spaced review). It never applies to weak or unseen types, so it
 *   can't dilute the push toward what you're missing.
 *
 * Finally no single type may take more than MAX_SHARE of the probability, so a
 * bad streak on one type can't turn the drill into a single-question loop.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.AdaptiveModel = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const DEFAULTS = {
    decay: 0.85,          // weight kept by older answers each time the type is answered again
    priorMisses: 0.3,     // prior: a type you've never seen is assumed 30% missed,
    priorAttempts: 1,     //   worth one answer of evidence
    floor: 0.1,
    gain: 4,
    staleAfter: 60,       // questions without seeing a known type before the full staleness boost
    staleBoost: 0.3,      // up to +30%
    maxShare: 0.3,
    focusThreshold: 0.45  // miss rate at which a type is flagged as a focus area
  };

  function normalize(ws) {
    const sum = ws.reduce((s, w) => s + w, 0);
    return sum > 0 ? ws.map((w) => w / sum) : ws.map(() => 1 / ws.length);
  }

  // Clip any share above `cap` and hand the excess to the others in proportion.
  function capShares(p, cap) {
    if (!(cap > 0) || cap * p.length < 1) return p;
    p = p.slice();
    for (let iter = 0; iter < 20; iter++) {
      let excess = 0, freeMass = 0;
      p.forEach((x) => { if (x > cap) excess += x - cap; else freeMass += x; });
      if (excess < 1e-12) break;
      p = p.map((x) => (x > cap ? cap : x + (freeMass > 0 ? (excess * x) / freeMass : 0)));
    }
    return p;
  }

  class AdaptiveModel {
    /**
     * @param {{id: string, base?: number}[]} types
     * @param {object} [opts] overrides for DEFAULTS
     */
    constructor(types, opts) {
      this.opts = Object.assign({}, DEFAULTS, opts || {});
      this.ids = types.map((t) => t.id);
      this.base = {};
      types.forEach((t) => { this.base[t.id] = t.base > 0 ? t.base : 1; });
      this.clock = 0;
      this.stats = {};
      this.ids.forEach((id) => { this.stats[id] = AdaptiveModel.emptyStat(); });
    }

    static emptyStat() {
      return { n: 0, miss: 0, total: 0, totalMiss: 0, lastSeen: null };
    }

    /** Record one answered question. Unknown ids are ignored. */
    record(id, ok) {
      const s = this.stats[id];
      if (!s) return;
      const d = this.opts.decay;
      s.n = s.n * d + 1;
      s.miss = s.miss * d + (ok ? 0 : 1);
      s.total += 1;
      if (!ok) s.totalMiss += 1;
      this.clock += 1;
      s.lastSeen = this.clock;
    }

    /** Smoothed, recency-weighted miss rate in [0, 1]. */
    missRate(id) {
      const s = this.stats[id];
      if (!s) return 0;
      const o = this.opts;
      return (s.miss + o.priorMisses) / (s.n + o.priorAttempts);
    }

    staleness(id) {
      const s = this.stats[id];
      if (!s || s.lastSeen === null || this.missRate(id) >= this.opts.focusThreshold) return 1;
      const since = this.clock - s.lastSeen;
      return 1 + this.opts.staleBoost * Math.min(1, since / this.opts.staleAfter);
    }

    weight(id) {
      const o = this.opts;
      return this.base[id] * (o.floor + o.gain * this.missRate(id)) * this.staleness(id);
    }

    /** True once a type has enough evidence and a high miss rate. */
    isFocus(id) {
      const s = this.stats[id];
      return !!s && s.total >= 2 && this.missRate(id) >= this.opts.focusThreshold;
    }

    /**
     * Probability of asking each type next.
     * @param {string|null} exclude  a type to skip (e.g. the one just asked)
     * @param {boolean} [adaptive=true]  false = the plain base mix
     * @returns {Object<string, number>}
     */
    probabilities(exclude, adaptive) {
      const ids = this.ids.filter((id) => id !== exclude);
      const useAdaptive = adaptive !== false;
      let p = normalize(ids.map((id) => (useAdaptive ? this.weight(id) : this.base[id])));
      if (useAdaptive) p = capShares(p, this.opts.maxShare);
      const out = {};
      ids.forEach((id, i) => { out[id] = p[i]; });
      return out;
    }

    /** Draw the next type. `rand` returns a number in [0, 1). */
    pick(rand, exclude, adaptive) {
      const probs = this.probabilities(exclude, adaptive);
      const ids = Object.keys(probs);
      let r = (rand || Math.random)();
      for (const id of ids) { r -= probs[id]; if (r < 0) return id; }
      return ids[ids.length - 1];
    }

    /** Rows for display, weakest first. */
    summary(exclude, adaptive) {
      const probs = this.probabilities(exclude, adaptive);
      return this.ids.map((id) => {
        const s = this.stats[id];
        return {
          id,
          total: s.total,
          missed: s.totalMiss,
          missRate: this.missRate(id),
          focus: this.isFocus(id),
          askRate: probs[id] || 0
        };
      }).sort((a, b) => (b.total > 0) - (a.total > 0) || b.missRate - a.missRate || b.askRate - a.askRate);
    }

    reset() {
      this.clock = 0;
      this.ids.forEach((id) => { this.stats[id] = AdaptiveModel.emptyStat(); });
    }

    toJSON() {
      return { version: 1, clock: this.clock, stats: this.stats };
    }

    /** Restore saved stats; tolerant of missing, extra or malformed entries. */
    load(data) {
      if (!data || typeof data !== "object" || !data.stats) return false;
      this.reset();
      this.clock = Number(data.clock) || 0;
      this.ids.forEach((id) => {
        const s = data.stats[id];
        if (!s) return;
        const num = (v) => (typeof v === "number" && isFinite(v) && v >= 0 ? v : 0);
        this.stats[id] = {
          n: num(s.n), miss: Math.min(num(s.miss), num(s.n)),
          total: num(s.total), totalMiss: Math.min(num(s.totalMiss), num(s.total)),
          lastSeen: typeof s.lastSeen === "number" ? s.lastSeen : null
        };
      });
      return true;
    }

    /**
     * Rebuild stats by replaying saved question logs (oldest first).
     * @param {{type?: string, tag?: string, ok: boolean}[]} entries
     * @param {Object<string, string>} tagToId  maps older log entries (tag only) to a type id
     */
    replay(entries, tagToId) {
      entries.forEach((e) => {
        const id = e.type || (tagToId && tagToId[e.tag]);
        if (id) this.record(id, !!e.ok);
      });
    }
  }

  AdaptiveModel.DEFAULTS = DEFAULTS;
  AdaptiveModel.capShares = capShares;
  return AdaptiveModel;
});
